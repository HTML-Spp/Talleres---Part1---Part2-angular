import { Serie } from "./serie.js";
export const series = [
    new Serie(1, "Breaking Bad", "AMC", 5, "", "https://www.amc.com/shows/breaking-bad", ""),
    new Serie(2, "Orange is the New Black", "Netflix", 6, "", "https://www.netflix.com/", ""),
    new Serie(3, "Game of Thrones", "HBO", 7, "", "https://www.hbo.com/", ""),
    new Serie(4, "The Big Bang Theory", "CBS", 12, "", "https://www.cbs.com/", ""),
    new Serie(5, "Sherlock", "BBC", 4, "", "https://www.bbc.co.uk/", ""),
    new Serie(6, "A Very English Scandal", "BBC", 2, "", "https://www.bbc.co.uk/", "")
];
