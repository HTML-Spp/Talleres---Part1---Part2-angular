import { series } from "./data.js";

const tableBody = document.getElementById("series-table") as HTMLElement;
const averageElement = document.getElementById("average") as HTMLElement;

console.log("CARGANDO TODO");

series.forEach(serie => {
  const row = document.createElement("tr");

  row.innerHTML = `
    <td>${serie.id}</td>
    <td><a href="${serie.link}" target="_blank">${serie.name}</a></td>
    <td>${serie.channel}</td>
    <td>${serie.seasons}</td>
  `;

  tableBody.appendChild(row);
});

let total = 0;
series.forEach(s => total += s.seasons);

const promedio = total / series.length;

averageElement.innerHTML = `Seasons average: ${promedio}`;